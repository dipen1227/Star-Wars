package com.dipen.swapi.model;

public class Planet {
	

}
