package com.dipen.swapi.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.dipen.swapi.model.ChildObject;
import com.dipen.swapi.model.Component;
import com.dipen.swapi.model.Species;

/*
 * author : dipen
 * 
 * The APIService class contains swapi APIs consumption and call multiple APIs for the desired output.
 * 
 */

@Service
public class ApiService {

	private RestTemplate restTemplate = new RestTemplate();

	private static String baseApi = "https://swapi.dev/api/";

	//get all starships of Luke Skywalker
	public List<String> getStartshipsofLuke(String name) {
		List<String> starships = new ArrayList();
		try {

			Component component = restTemplate
					.exchange(baseApi + "/people", HttpMethod.GET, getEntity(), Component.class).getBody();

			List<ChildObject> results = component.getResults();
			for (ChildObject co : results) {
				if (co.getName().contentEquals(name)) {
					List<String> starshipUrls = co.getStarships();
					ChildObject childObject;
					for (String url : starshipUrls) {
						childObject = restTemplate.exchange(url, HttpMethod.GET, getEntity(), ChildObject.class)
								.getBody();
						starships.add(childObject.getName());
					}
				}
			}

		} catch (Exception e) {
		}
		return starships;
	}

	//get all unique Species of 1st Episode
	
	public Set<String> getSpicesOfFirstEpisode(int episode) {
		Set<String> species = new HashSet();

		Component component = restTemplate.exchange(baseApi + "/films", HttpMethod.GET, getEntity(), Component.class)
				.getBody();

		List<ChildObject> results = component.getResults();
		for (ChildObject co : results) {
			if (co.getEpisodeId() == episode) {
				List<String> specieUrls = co.getSpecies();
				for (String url : specieUrls) {
					Species s = restTemplate.exchange(url, HttpMethod.GET, getEntity(), Species.class).getBody();
					species.add(s.getClassification());
				}
			}
		}

		return species;
	}

	//get population of All planets
	public Long getTotalPopulationOfAllPlanets() {
		Component component = null;
		Long totalPopulation = 0L;
		String url = baseApi + "planets";
		do {
			component = restTemplate.exchange(url, HttpMethod.GET, getEntity(), Component.class).getBody();
			List<ChildObject> childObjects = component.getResults();
			for (ChildObject co : childObjects) {
				try {
					totalPopulation += Long.parseLong(co.getPopulation());
				} catch (Exception e) {
				}
			}
			url = component.getNext();
		} while (component.getNext() != null);

		return totalPopulation;
	}

	private HttpEntity<String> getEntity() {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		HttpEntity<String> entity = new HttpEntity<String>(headers);
		return entity;
	}

}
