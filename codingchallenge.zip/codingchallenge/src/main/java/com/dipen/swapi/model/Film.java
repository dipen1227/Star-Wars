package com.dipen.swapi.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Film {



}
